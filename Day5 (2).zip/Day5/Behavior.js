import Component from "./Component.js"

class Behavior extends Component{

    start(){

    }

    update(){
        
    }

}

export default Behavior;
import Behavior from "./Behavior.js"

class SmallCircleBehavior extends Behavior{
    time = 0;
    positionX = 0;
    positionY = 0;
    speed = 5;
    goingLeft = true;
    goingDown = true;
    start(){
        this.gameObject.x = 1000;
        this.gameObject.y = 1000;
    }
    update(){
        this.time += 1;
        if(this.goingLeft){
            this.positionX -= this.speed;
        }
        else{
            this.positionX += this.speed;
        }

        if(this.positionX < 400){
            this.goingLeft = false;
        }
        if(this.positionX > 1800){
            this.goingLeft = true;
        }

        if(this.goingDown){
            this.positionY -= this.speed;
        }
        else{
            this.positionY += this.speed;
        }

        if(this.positionY < 150){
            this.goingDown = false;
        }
        if(this.positionY > 650){
            this.goingDown = true;
        }

        this.gameObject.x = this.positionX;
        this.gameObject.y = this.positionY;

        //this.gameObject.x = Math.sin(this.time/25)*50+50;
    }
}

export default SmallCircleBehavior;
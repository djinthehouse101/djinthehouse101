class Time{
    static deltaTime = 0;
}

export default Time;